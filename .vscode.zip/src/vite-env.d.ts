/// <reference types="vite/client" />
/// <reference types="element-plus/global.d.ts" />